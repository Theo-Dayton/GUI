/*
 * Frame class, simple frame class which extends JFrame
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Frame extends JFrame {
    public Frame () { 
        }
}