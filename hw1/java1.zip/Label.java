/*
 * Label class, simple label class which takes a string, which is used as its
 * text
 */

import javax.swing.*;

public class Label extends JLabel { 
    public Label (String label) { 
	setText (label); 
    }
}
