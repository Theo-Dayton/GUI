rm *.class
javac Main.java
java Main