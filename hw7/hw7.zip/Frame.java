/*
 * Frame class, simple frame class which extends JFrame
 */

import javax.swing.*;

class Frame extends JFrame{
    public Frame () { 
            
        }
}